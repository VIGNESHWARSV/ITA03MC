
const express = require('express');
const Appointment = require('../models/Appointment');
const router = express.Router();

router.post('/', async (req, res) => {
  const { userId, doctor, date, time } = req.body;
  const appointment = new Appointment({ userId, doctor, date, time });
  await appointment.save();
  res.json(appointment);
});

router.get('/:userId', async (req, res) => {
  const appointments = await Appointment.find({ userId: req.params.userId });
  res.json(appointments);
});

module.exports = router;
