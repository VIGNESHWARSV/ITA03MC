
const express = require('express');
const Prescription = require('../models/Prescription');
const router = express.Router();

router.post('/', async (req, res) => {
  const { userId, medicine, dosage, notes } = req.body;
  const prescription = new Prescription({ userId, medicine, dosage, notes });
  await prescription.save();
  res.json(prescription);
});

router.get('/:userId', async (req, res) => {
  const prescriptions = await Prescription.find({ userId: req.params.userId });
  res.json(prescriptions);
});

module.exports = router;
