
const mongoose = require('mongoose');

const PrescriptionSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  medicine: String,
  dosage: String,
  notes: String
});

module.exports = mongoose.model('Prescription', PrescriptionSchema);
