
const mongoose = require('mongoose');

const AppointmentSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  doctor: String,
  date: String,
  time: String
});

module.exports = mongoose.model('Appointment', AppointmentSchema);
